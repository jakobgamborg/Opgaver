﻿using System;
using TennisSimulator.Tennis;

namespace TennisSimulator
{
    class Program
    {
        static void Main(string[] args)
        {
            CLIhandler newClIhandler = new CLIhandler();
        }
    }
}
