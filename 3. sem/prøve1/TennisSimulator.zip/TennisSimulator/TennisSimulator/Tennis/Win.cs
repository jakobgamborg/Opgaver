﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TennisSimulator.Tennis
{
    class Win
    {
        public bool win { get; set; }

      
    }
}
